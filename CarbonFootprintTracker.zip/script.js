document.getElementById("footprintForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const travel = parseFloat(document.getElementById("travel").value) || 0;
  const electricity = parseFloat(document.getElementById("electricity").value) || 0;
  const meat = parseFloat(document.getElementById("meat").value) || 0;

  const travelEmission = travel * 0.21;
  const electricityEmission = electricity * 0.5;
  const meatEmission = meat * 2.5;

  const totalEmission = (
    travelEmission +
    electricityEmission +
    meatEmission
  ).toFixed(2);

  document.getElementById("result").innerHTML = `
    <h3>Your Weekly Carbon Footprint: ${totalEmission} kg CO₂</h3>
    <p>🌎 Travel: ${travelEmission.toFixed(2)} kg<br>
    💡 Electricity: ${electricityEmission.toFixed(2)} kg<br>
    🍗 Meat: ${meatEmission.toFixed(2)} kg</p>
  `;

  showChart([travelEmission, electricityEmission, meatEmission]);
});

function showChart(data) {
  const ctx = document.getElementById("emissionChart").getContext("2d");
  if (window.myChart) window.myChart.destroy();

  window.myChart = new Chart(ctx, {
    type: "pie",
    data: {
      labels: ["Travel", "Electricity", "Meat"],
      datasets: [{
        label: "CO₂ Emissions (kg)",
        data: data,
        backgroundColor: ["#4caf50", "#ff9800", "#f44336"],
        borderWidth: 1,
      }],
    },
    options: {
      responsive: true,
    },
  });
}
